print("Mój pierwszy program")
print("0023")