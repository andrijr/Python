x = "Przechowywany tekst"
a = 3
b = 5
c = 5.2
y = x[0:19]

wynik = a * b * c
suma = a + b
roznica = a - b
iloraz = a / b
potega = a ** b

print(x)
print("x")
print(a)
print(b)
print(c)
print(wynik)
print(suma)
print(roznica)
print(iloraz)
print(potega)
print(y)