x = "Przechowywanytekst"

print(type(x))

y = x[0] + x[1] + x[2] + x[3] + x[4] + x[5] + " - to jest wycięty tekst"

a = 3
b = 5
c = a + b

d = "3"
e = "5"
f = d + e

z = x[8:11]
tekstZeSpacja = x[0:13] + " " + x[13:18]
print(x)
print(y)
print(c)
print(f)
print(z)

print(len(x))
print(tekstZeSpacja)