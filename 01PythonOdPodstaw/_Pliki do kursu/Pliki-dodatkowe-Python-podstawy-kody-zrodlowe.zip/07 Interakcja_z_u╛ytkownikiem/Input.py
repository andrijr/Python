#Program obliczający średnią arytmetyczną z trzech podanych przez użytkownika liczb
print("Program obliczy średnią arytmetyczną z trzech podanych liczb")
a = float(input("Podaj pierwszą liczbę: "))
b = float(input("Podaj drugą liczbę: "))
c = float(input("Podaj trzecią liczbę: "))

print("Średnia arytmetyczna podanych liczb, to:",(a + b + c) / 3)

#Napisz program rozwiązujący (tzn. obliczający miejsca zerowe) trójmianu kwadratowego, np. 3x^2+5x-20