tekstLiczbowy = input("Podaj jakąś liczbę: ")
tekstLiczbowy = tekstLiczbowy * 5
liczba = int(tekstLiczbowy)
liczba /= 123
liczba = int(liczba)
wynikTekstowy = str(liczba)
wynikTekstowy = wynikTekstowy * 2
print(wynikTekstowy)
jakasLiczba = 55.8
print(round(jakasLiczba))
print(int(jakasLiczba))