def stopka():
    print("Jak widzisz ta aplikacja jest świetna")
    print("Ten tekst został wyświetlony przy użyciu funkcji")

x = int(input("Podaj pierwszą liczbę całkowitą: "))
y = int(input("Podaj drugą liczbę całkowitą: "))

print("Suma podanych liczb wynosi:",x+y)

stopka()

print("Różnica podanych liczb wynosi:",x-y)

stopka()

print("Iloczyn podanych liczb wynosi:",x*y)

stopka()