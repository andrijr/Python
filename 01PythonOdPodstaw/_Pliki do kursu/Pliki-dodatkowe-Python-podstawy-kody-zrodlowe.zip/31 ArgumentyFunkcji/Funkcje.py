def dodawanie(a: int, b: int):
    print("Wynik dodawania tych dwóch liczb to:",a+b)
    print("Świetna aplikacja dodająca")
    print("To jest funkcja")

x = input("Podaj pierwszą liczbę do dodania: ")
y = input("Podaj drugi składki sumy: ")

dodawanie(x,y)
dodawanie(y,x)