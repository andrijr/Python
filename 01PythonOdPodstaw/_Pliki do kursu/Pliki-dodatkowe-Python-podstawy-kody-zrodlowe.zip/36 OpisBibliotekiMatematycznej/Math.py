import math

print(math.floor(3.6))
print(math.ceil(3.4))

print(sum([1,2,3,4,5,6,7,8]))
print(math.fsum([1,2,3,4,5,6,7,8]))
print(sum([0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1]))
print(math.fsum([0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1]))

print(math.gcd(13224323425,43242344220))

print(math.sqrt(4))

print(math.log(9,3))

print(math.sin(math.radians(30)))

print(math.pi)

print(math.sin(2*math.pi))

print(math.e)