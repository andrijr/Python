def add(lista):
    sum = 0
    for element in lista:
        sum += element
    return sum

def multiply(lista):
    product = 1
    for element in lista:
        product *= element
    return product