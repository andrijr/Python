import datetime
import math
# print("Pierwsza implementacja")
#
# time.clock()
#
# lista = []
# for x in range(1,10000000):
#     lista.append(x**2)
#
# print("Trwało to: ",time.clock())
#
# print("\n\nDruga implementacja")
#
# time.clock()
#
# lista2 = []
# for x in range(1,10000000):
#     lista2.append(math.pow(x,2))
#
# print("Trwało to: ", time.clock())

# for x in range(0,10):
#     print(10-x)
#     time.sleep(0.5)

aktualnyCzas = datetime.datetime.now()

print(aktualnyCzas)