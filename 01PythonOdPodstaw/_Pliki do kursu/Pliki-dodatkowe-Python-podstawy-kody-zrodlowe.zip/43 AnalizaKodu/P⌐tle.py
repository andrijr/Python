lista = [[1,2],[1,3],[1,4]]

# for i in range(0,len(lista)):
#     for j in range(0,len(lista[i])):
#         print(lista[i][j])

for wewnetrznaLista in lista:
    for element in wewnetrznaLista:
        print(element)