import math

#Program sprawdza równości między liczbami

# print(3 == 3)
# print(math.sqrt(2) == math.sqrt(2))
# print(5**4 == 625)
# print(math.sqrt(3) == 3 ** 0.5)
# print(10*0.1 - 1 == 0)
print(math.sqrt(4) == 2)
# print(0*1 == 0)
# print(5**0 == 1)
