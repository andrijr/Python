import random
x = random.randint(1, 100)
print(x)