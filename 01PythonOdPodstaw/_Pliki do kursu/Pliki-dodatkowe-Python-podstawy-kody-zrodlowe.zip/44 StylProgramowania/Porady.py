#Używaj komentarzy, ale nie często. Jedynie tam gdzie czytający kod (również ty) może się pogubić
#Nazywaj obiekty tak, żeby coś znaczyły - zamiast obiektu "ab"  - posiadającego listę wczytanych liczb o wiele lepszą nazwą wydaje się "wczytane" lub "enteredNumbers"
#Używaj tego samego stylu - nie nazywaj funkcji raz camelCasem, np. "niceFunction", a innym razem "very_good_function"
#Staraj się używać nazw w języku angielskim
#Używaj pełnej gamy dostępnych kolekcji
#Jeżeli funkcja, którą piszesz przekracza 10 linijek kodu zastanów się czy nie należy jej rozbić
#Wydzielaj powtarzające się elementy