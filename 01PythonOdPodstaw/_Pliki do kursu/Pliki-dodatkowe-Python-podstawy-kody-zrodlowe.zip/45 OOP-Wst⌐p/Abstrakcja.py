class Dog:
    def giveVoice(self):
        print("hau hau!")

szarik = Dog()
azor = Dog()

azor.giveVoice()
szarik.giveVoice()