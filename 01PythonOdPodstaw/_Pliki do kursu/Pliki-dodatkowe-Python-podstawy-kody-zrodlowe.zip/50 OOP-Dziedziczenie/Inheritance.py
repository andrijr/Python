import Animal

mruczek = Animal.Cat(3,"Mruczek","brytyjski")

mruczek.printInformation()
mruczek.giveTheVoice()

mruczek.go()

print()
pies = Animal.Dog(5,"Azor","Dalmatyńczyk")
pies.printInformation()