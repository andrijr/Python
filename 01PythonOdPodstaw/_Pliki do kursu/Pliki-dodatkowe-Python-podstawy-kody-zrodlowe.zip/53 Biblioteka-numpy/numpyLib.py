import numpy

matrix = numpy.random.random((2,5))

print(matrix)