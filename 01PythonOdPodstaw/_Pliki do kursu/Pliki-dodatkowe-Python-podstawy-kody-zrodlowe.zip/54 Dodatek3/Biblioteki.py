#Matematyka: numpy, SciPy, matplotlib, SymPy
#Gry: pygame,Pyglet,PySFML
#Windows: pywin32
#Aplikacje internetowe: Django, Requests
#Aplikacje okienkowe: tkinter, wxPython, pyGTK, Maya
#ntlk - operowanie na stringach zawierających tekst
#Operacje na obrazach: PIL, Pillow
#scikit-learn - biblioteka do uczenia maszynowego
#py2exe - konwersja aplikacji napisanej w Pythonie do pliku uruchamialnego exe
