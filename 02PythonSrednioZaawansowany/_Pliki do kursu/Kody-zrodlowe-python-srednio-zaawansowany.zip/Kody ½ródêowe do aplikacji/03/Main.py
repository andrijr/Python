from Duck import *

myDuck = Duck(3,"żółta")

myDuck.fly()
myDuck.say()

myDuckToy = DuckToy("czerwona","gumowa")

myDuckToy.fly()
myDuckToy.say()