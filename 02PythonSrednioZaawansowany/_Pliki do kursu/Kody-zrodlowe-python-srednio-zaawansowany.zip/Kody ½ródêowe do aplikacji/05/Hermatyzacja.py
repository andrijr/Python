from PrzykladKlasy import Temp

obiekt = Temp()
obiekt.printMe()
print(obiekt.__a)