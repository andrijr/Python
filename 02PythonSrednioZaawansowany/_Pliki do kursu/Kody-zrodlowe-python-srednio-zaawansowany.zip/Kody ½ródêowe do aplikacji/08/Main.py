from Foo import Foo

# print(Foo.pole)
# obiekt = Foo()
#
# print(obiekt.pole)
#
# obiekt.pole = 5
#
# print()
# print(obiekt.pole)
# print(Foo.pole)

obiekt = Foo()
obiekt.a = -11
print(obiekt.a)