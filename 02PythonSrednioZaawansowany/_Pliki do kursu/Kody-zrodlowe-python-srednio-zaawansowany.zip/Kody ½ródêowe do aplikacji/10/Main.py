a = 3
b = 5

#I Sposób
# temp = a
# a = b
# b = temp

#II Sposób
# b = a + b #b = 8
# a = b - a #a = 5
# b = b - a #b = 3

#III Sposób
a, b = b, a

#c, d, e = [1, 2, 3]

print("a:",a,"oraz b:",b)