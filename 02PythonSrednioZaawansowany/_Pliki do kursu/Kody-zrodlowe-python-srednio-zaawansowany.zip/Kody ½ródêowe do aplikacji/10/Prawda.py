# x = True
# y = False
# a = 1
# print((x == 2) == 0)

# slownik = {True: 'a', 1: 'b', 1.0: 'c'}
# print(slownik)