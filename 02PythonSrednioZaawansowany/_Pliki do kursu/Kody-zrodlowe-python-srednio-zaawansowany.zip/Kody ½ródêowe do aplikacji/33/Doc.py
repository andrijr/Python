def funkcja(a,b,c):
    """Funkcja funkcja przyjmuje trzy liczby całkowite i zwraca ich sumę
    dalej
    kolejne linie dokumentacji
    fsd"""
    return a+b+c