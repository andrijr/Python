import Doc
from Trimmer import trim

Doc.funkcja(1,2,3)

print(trim(Doc.funkcja.__doc__))